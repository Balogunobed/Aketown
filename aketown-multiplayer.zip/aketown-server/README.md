# Aketown multiplayer server (v0.6)

One Node process. No npm install. It serves the game from `./public` and runs the multiplayer on the same address.

## Run it here
```
node server.js          # http://localhost:8080
node test.js            # integration tests (starts its own server on port 8099)
```
Open the address in two browser windows to see yourself from the other side.

## Put it online
Any host that runs a long-lived Node process and allows WebSockets:
- **Render**: New > Blueprint, point at this folder in a Git repo (uses `render.yaml`, includes a 1 GB disk for the save file).
- **Railway / Fly.io / a VPS**: run `node server.js`, or build the included `Dockerfile` and mount a volume at `/data`.
- Netlify, Vercel and Cloudflare Pages cannot host this part (no persistent WebSocket server).

Environment variables: `PORT`, `DATA_FILE` (path of the JSON data file, keep it on a persistent disk), `ADMIN_KEY` (turns on admin tools), `MAX_ROOM` (players per city, default 16).

## What the server does
- **Accounts**: each browser gets a private token on first visit; the server issues a player ID and a recovery key. Sign in on another device with the ID and key (Phone > Online > Account).
- **Money**: the server holds each balance. Rewards are only paid for known categories, under a cap, after a job really started and ran for a minimum time, with a cooldown. Everything else is refused. Spending (shops, arcade entry, agbero levies) is always allowed up to your balance. Arcade prizes need an arcade game to have been started (12 s minimum, 20 s between prizes, max ₦800). Looting a knocked-out person is capped at ₦1,200 with an 8 s gap.
- **Cities and private sessions**: up to 16 per room. Create a private session and share the invite link, or join friends from the friends list.
- **Street race**: 2 to 8 players, 30 second lobby, server countdown, 16 checkpoints in order with a speed limit, results, prizes and a leaderboard.
- **Co-op delivery**: 2 to 4 players, everyone must reach the pickup and the drop-off together. ₦4,000 each.
- **Crews**: create (₦2,500) or join by name, tag in the name plate, crew chat with `/c message`, crew ranking.
- **Friends, block and report**: block is per player and stays on the device; 3 reports in 10 minutes mutes a player for 10 minutes.
- **Chat filter, rate limits and sanity checks** on names, chat, positions, punches and every message.
- **Admin** (when `ADMIN_KEY` is set): `/admin/state?key=…`, `/admin/kick?key=…&code=ID`, `/admin/ban?key=…&code=ID`.

## New in v0.5 (single-player features that also work online)
- **Agbero (touts)** at street corners ask for a park fee when you pass; pay, or refuse and they chase you.
- **Weapons**: stick, bottle, plank, iron rod (hardware stall, Alhaja's shop). R switches weapon. Weapons wear out, and the police confiscate them if you are arrested.
- **Everyone can be hurt**: pedestrians, agbero and police take damage (fists, weapons, being run over). Knock someone down and press E to take their cash. Some fight back.
- **Buildings you can enter**: your flat (sleep until 06:00 or 18:00 to skip time and restore health), Bello Pharmacy and Alhaja's Provisions (heal), the hardware stall, and Naija Games Arcade (pool, penalty shootout, bike race). Shops have opening hours.
- Server: new claim rules `Arcade · …` (job type `arcade`) and `Looted …`.

## What it does not do yet (be honest before inviting strangers)
- Movement, combat feel and police are still simulated on each player's device. The server clamps and rate limits them but cannot stop a determined cheater from faking a position. Race checkpoints are checked for order and speed, not map geometry.
- Traffic, pedestrians, police, agbero, looting and the arcade games are not shared between players. The arcade is single-player; the server only pays the prize, and cannot see whether you really won.
- Data lives in one JSON file. For a real launch move it to PostgreSQL (the data shape in `server.js` maps to four tables: players, crews, board, reports) and add email or social sign-in.
- One process, one machine. Past about 100 to 200 players you would split rooms across processes.

## New in v0.6.4
- Job offers no longer sit on top of the objective box (the objective hides while an offer or dialogue is showing, and the offer wraps cleanly on phones). Tap anywhere on the screen to advance dialogue.

## New in v0.6.3
- **Map waypoint**: tap anywhere on the map to drop a waypoint; the HUD arrow and minimap guide you there, a light beam marks it in the world, and it clears on arrival (or with Clear waypoint). Your mission objective keeps its own gold marker.
- **Footballs** on both pitches: run into the ball to dribble, Q (or the punch button) to kick, cars knock it about, and goals are counted. The ball is local to each player, not synced online.

## New in v0.6.4
- Job offers no longer sit on top of the objective box (the objective hides while an offer or dialogue is showing, and the offer wraps cleanly on phones). Tap anywhere on the screen to advance dialogue.

## New in v0.6.3
- **Map waypoints**: tap the map to mark a destination; the objective arrow, minimap and a 3D beam guide you. Clear it from the map screen.
- **Footballs**: one on each pitch (Eastgate and Southside). Run into it to dribble, Q or the punch button to kick; cars knock it too.

## New in v0.6.2
- **Arrest choice**: when the police catch you, settle on the spot (₦3,000 + ₦1,500 per wanted level, keep your gear) or go to jail (2 to 9.5 game hours, fine, weapons confiscated, released at Police HQ). You can only settle if you can pay.

## New in v0.6.1
- **Lagoon Grand Hotel**: a 5-star hotel with a lobby, reception and lounge bar. Rooms cost ₦40,000, ₦95,000 and ₦220,000; you wake at the time you choose with full health. Doormen turn you away while you are wanted. Spending goes through the same balance checks as shops.
- **Multiplayer button on the main menu**: connects to the shared city, creates a private session (code to share) or joins one by code.

## New in v0.6
- **Arcade leaderboards** (pool, penalty shootout, bike race): scores are submitted with `{t:'score',game,score}`. The server needs an active arcade job, a minimum play time (pool 6 s, penalty 15 s, bike 18 s), a score under the game's cap, and accepts one score per play. Top 10, your rank and your best show in the arcade and in Phone > Board.
- **Spelling bee**: the browser's speech voice says a word, players type the spelling.
  - Solo: 5 words, pays up to ₦1,300 (job `bee`, 20 s minimum, 30 s cooldown); solo scores are on the board.
  - Live: join from the community hall or Phone > Activities. 2 or more players, 30 s lobby, 8 words (3 easy, 3 medium, 2 hard), 25 s per word. Prizes ₦4,000 / 2,000 / 1,000, and ₦300 for 3+ correct.
  - Test timings can be overridden with `BEE_LOBBY_MS`, `BEE_LEAD_MS`, `BEE_REVEAL_MS`.
- **Police vs agbero**: beat officers stand at posts. If a tout hurts you in front of one, the officer chases and arrests him.
- **Agbero ask for money far less often.**
- **Gun dealer**: a pistol (₦18,000) and ammo, sold at the dealer's shop. Shooting in view of police raises your wanted level; an arrest confiscates the gun.
- **Bigger map** with more roads, districts and buildings.

New messages: `score`, `arcb`/`arcboard`, `bee` (`join`, `leave`, `ans`, `state`). `lb` now carries `arc`, `bee` and `beeSolo`.

## Limits to know about
- Speech quality depends on the player's device. If no voice exists the word is shown on screen.
- Live bee words are sent to the browser so it can speak them; a determined cheater can read them from the network.
- Arcade scores are checked by caps, minimum time and one-per-play, not by replaying the game.
