'use strict';
/* Aketown multiplayer server. Zero dependencies (Node 18+): HTTP + hand-rolled WebSocket.
   Authoritative for: accounts, money and reward validation, rooms and private sessions, races, co-op deliveries,
   crews, friends, leaderboards, rate limits, reports. Clients still own their own movement and combat feel. */
const http = require('http'), crypto = require('crypto'), fs = require('fs'), path = require('path');
const PORT = +process.env.PORT || 8080;
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const ADMIN_KEY = process.env.ADMIN_KEY || '';
const MAX_ROOM = +process.env.MAX_ROOM || 16;
const PUB = path.join(__dirname, 'public');
const now = () => Date.now();

/* ---------- storage (JSON file; swap for PostgreSQL later, same shape) ---------- */
let DB = { players: {}, byTok: {}, byCode: {}, crews: {}, board: { race: [] }, reports: [], bans: {} };
try { DB = Object.assign(DB, JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))); } catch (e) {}
DB.board = DB.board || { race: [] }; DB.board.race = DB.board.race || [];
DB.board.arc = DB.board.arc || {}; for (const g of ['pool', 'pen', 'bike', 'bee']) DB.board.arc[g] = DB.board.arc[g] || {};   // game -> { playerId: {score, at} }
DB.board.bee = DB.board.bee || {};                                                                                      // playerId -> {pts, wins, games}
const BEE_WORDS = require('./words.js');
let dirty = false;
function saveDB() {
  if (!dirty) return; dirty = false;
  try { fs.writeFileSync(DATA_FILE + '.tmp', JSON.stringify(DB)); fs.renameSync(DATA_FILE + '.tmp', DATA_FILE); } catch (e) { console.error('save failed', e.message); }
}
setInterval(saveDB, 15000);
for (const sig of ['SIGTERM', 'SIGINT']) process.on(sig, () => { dirty = true; saveDB(); process.exit(0); });

/* ---------- helpers ---------- */
const rid = n => { const a = 'abcdefghijklmnopqrstuvwxyz0123456789'; let s = ''; const b = crypto.randomBytes(n); for (let i = 0; i < n; i++) s += a[b[i] % 36]; return s; };
const codeGen = n => { const a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let s = ''; const b = crypto.randomBytes(n); for (let i = 0; i < n; i++) s += a[b[i] % a.length]; return s; };
const sha = s => crypto.createHash('sha256').update(String(s)).digest('hex');
const num = (v, l) => (typeof v === 'number' && isFinite(v)) ? Math.max(-l, Math.min(l, v)) : null;
const BAD = /\b(fuck\w*|shit\w*|bitch\w*|cunt|nigg\w*|asshole|dick\w*|pussy|bastard|whore|slut)\b/gi;
const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f​-‏‪-‮⁦-⁩]/g, '').slice(0, n);
const filt = s => clean(s, 120).replace(BAD, m => '*'.repeat(m.length)).trim();
function goodName(s) { s = clean(s, 16).replace(/\s+/g, ' ').trim(); if (s.length < 2) return ''; if (BAD.test(s)) { BAD.lastIndex = 0; return ''; } BAD.lastIndex = 0; return s; }

/* ---------- minimal WebSocket ---------- */
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
function frame(op, buf) {
  const len = buf.length; let h;
  if (len < 126) h = Buffer.from([0x80 | op, len]);
  else if (len < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(len, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([h, buf]);
}
class Conn {
  constructor(sock) {
    this.sock = sock; this.buf = Buffer.alloc(0); this.frag = []; this.alive = true; this.id = rid(12);
    this.p = null; this.room = null; this.pres = {}; this.job = null; this.win = { t: 0, n: 0 }; this.gap = {}; this.mutedUntil = 0; this.ip = sock.remoteAddress;
    sock.on('data', d => this.feed(d)); sock.on('close', () => this.close()); sock.on('error', () => this.close());
  }
  feed(chunk) {
    this.buf = Buffer.concat([this.buf, chunk]);
    if (this.buf.length > 70000) return this.kill();
    for (;;) {
      const b = this.buf; if (b.length < 2) return;
      const fin = !!(b[0] & 0x80), op = b[0] & 15, masked = !!(b[1] & 0x80); let len = b[1] & 127, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; const L = b.readBigUInt64BE(2); if (L > 65536n) return this.kill(); len = Number(L); off = 10; }
      if (!masked) return this.kill();
      if (b.length < off + 4 + len) return;
      const mask = b.slice(off, off + 4), data = Buffer.from(b.slice(off + 4, off + 4 + len));
      for (let i = 0; i < len; i++) data[i] ^= mask[i & 3];
      this.buf = b.slice(off + 4 + len);
      if (op === 8) return this.kill();
      if (op === 9) { this.raw(10, data); continue; }
      if (op === 10) continue;
      if (op === 1 || op === 0) {
        this.frag.push(data);
        if (this.frag.reduce((a, x) => a + x.length, 0) > 20000) return this.kill();
        if (fin) { const txt = Buffer.concat(this.frag).toString('utf8'); this.frag = []; this.msg(txt); }
      }
    }
  }
  raw(op, buf) { if (this.alive && this.sock.writable) { if (this.sock.writableLength > 1e6) return this.kill(); this.sock.write(frame(op, buf)); } }
  send(o) { this.raw(1, Buffer.from(JSON.stringify(o))); }
  kill() { try { this.raw(8, Buffer.alloc(0)); this.sock.end(); this.sock.destroy(); } catch (e) {} this.close(); }
  close() { if (!this.alive) return; this.alive = false; onClose(this); }
  msg(txt) {
    const t = now();
    if (t - this.win.t > 1000) { this.win.t = t; this.win.n = 0; }
    if (++this.win.n > 60) { if (this.win.n > 300) this.kill(); return; }
    let m; try { m = JSON.parse(txt); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    try { onMsg(this, m); } catch (e) { console.error('handler', m.t, e.stack); }
  }
  limit(key, ms) { const t = now(); if (t - (this.gap[key] || 0) < ms) return false; this.gap[key] = t; return true; }
}

/* ---------- accounts ---------- */
const online = new Map();   // conn.id -> conn
const byPid = new Map();    // player id -> conn
function newPlayer(name) {
  const id = rid(10); let code; do code = codeGen(6); while (DB.byCode[code]);
  const tok = rid(32), rk = codeGen(4) + '-' + codeGen(4);
  const p = { id, th: sha(tok), name, code, rk: sha(rk), money: 3500, earned: 0, jobs: 0, bestRace: 0, crew: null, friends: [], blob: '', created: now(), seen: now() };
  DB.players[id] = p; DB.byTok[p.th] = id; DB.byCode[code] = id; dirty = true;
  return { p, tok, rkPlain: rk };
}
const dn = p => (p.crew && DB.crews[p.crew.toLowerCase()] ? '[' + DB.crews[p.crew.toLowerCase()].tag + '] ' : '') + p.name;

/* ---------- rooms ---------- */
const rooms = new Map();    // name -> {name,priv,members:Set,race,coop}
function getRoom(name, priv) { let r = rooms.get(name); if (!r) { r = { name, priv: !!priv, members: new Set(), race: null, coop: null, bee: null, chat: [] }; rooms.set(name, r); } return r; }
function publicRoom() { for (const r of rooms.values()) if (!r.priv && r.members.size < MAX_ROOM) return r; let i = 1; while (rooms.has('L' + i)) i++; return getRoom('L' + i, false); }
function toRoom(r, o, except) { for (const c of r.members) if (c !== except) c.send(o); }
function presOut(c) { return Object.assign({}, c.pres, { n: dn(c.p), c: c.p.code }); }
function joinRoom(c, r) {
  if (c.room === r) return;
  leaveRoom(c);
  c.room = r; r.members.add(c);
  const peers = []; for (const o of r.members) if (o !== c && o.pres.x != null) peers.push({ id: o.id, pr: presOut(o) });
  c.send({ t: 'room', name: r.name, priv: r.priv, code: r.priv ? r.name : null, peers, n: r.members.size });
  if (c.pres.x != null) toRoom(r, { t: 'p', id: c.id, pr: presOut(c) }, c);
}
function leaveRoom(c) {
  const r = c.room; if (!r) return;
  r.members.delete(c); c.room = null;
  toRoom(r, { t: 'bye', id: c.id });
  raceDrop(r, c); coopDrop(r, c); beeDrop(r, c);
  if (!r.members.size && r.priv) rooms.delete(r.name);
}
function onClose(c) {
  online.delete(c.id); if (c.p) { if (byPid.get(c.p.id) === c) byPid.delete(c.p.id); c.p.seen = now(); dirty = true; }
  leaveRoom(c);
}

/* ---------- reward validation ---------- */
const CLAIMS = [
  { re: /^First Delivery/, max: 22000, gap: 300 },
  { re: /^Food delivery/, job: 'food', max: 2300, sec: 8 },
  { re: /^Taxi job/, job: 'taxi', max: 4600, sec: 10 },
  { re: /^Courier/, job: 'courier', max: 5000, sec: 8 },
  { re: /^Market delivery/, job: 'market', max: 6800, sec: 10 },
  { re: /^Vehicle recovery/, job: 'recover', max: 10500, sec: 10 },
  { re: /^Police escape/, job: 'escape', max: 8000, sec: 30 },
  { re: /^Street race/, job: 'race', max: 10000, sec: 25 },
  { re: /^Mystery package/, max: 3300, gap: 40 },
  { re: /^Helped /, max: 800, gap: 30 },
  { re: /^Arcade · /, job: 'arcade', max: 800, sec: 12, gap: 20 },
  { re: /^Looted /, max: 1200, gap: 8 },
  { re: /^Spelling bee · solo/, job: 'bee', max: 1300, sec: 20, gap: 30 }
];
function pay(p, amt, label) {
  p.money = Math.max(0, Math.round(p.money + amt)); if (amt > 0) p.earned += amt; dirty = true;
  const c = byPid.get(p.id); if (c) c.send({ t: 'bal', money: p.money, delta: amt, label: label || '' });
}
function claim(c, label, amt) {
  const p = c.p; label = clean(label, 60); amt = Math.round(+amt);
  if (!isFinite(amt) || amt === 0) return;
  if (amt < 0) { amt = Math.max(amt, -p.money, -60000); if (amt) pay(p, amt, label); else c.send({ t: 'bal', money: p.money, delta: 0, label }); return; }
  const rule = CLAIMS.find(r => r.re.test(label));
  const deny = why => c.send({ t: 'deny', label, why });
  if (!rule) return deny('unknown reward');
  if (amt > rule.max) return deny('amount too high');
  if (rule.job) {
    const j = c.job; if (!j || j.type !== rule.job) return deny('no active job');
    if ((now() - j.t0) / 1000 < rule.sec) return deny('too fast');
    if (rule.gap && !c.limit('claim:' + rule.re.source, rule.gap * 1000)) return deny('too soon');
    c.job = null; p.jobs++;
  } else if (!c.limit('claim:' + rule.re.source, (rule.gap || 0) * 1000)) return deny('too soon');
  pay(p, amt, label);
}

/* ---------- multiplayer race ---------- */
const RACE_CPS = 16, RACE_PRIZE = [10000, 5000, 2500, 1000];
function raceView(r) {
  const R = r.race; if (!R) return { t: 'race', st: 'idle' };
  return { t: 'race', st: R.st, startAt: R.startAt, lobbyEnds: R.lobbyEnds, now: now(), racers: [...R.p.values()].map(x => ({ id: x.c.id, name: dn(x.c.p), cp: x.cp, fin: x.fin ? Math.round(x.fin) : 0 })) };
}
function raceBroadcast(r) { const v = raceView(r); if (r.race) { for (const x of r.race.p.values()) x.c.send(v); } }
function raceJoin(c, r) {
  if (r.race && (r.race.st === 'running' || r.race.st === 'countdown')) return c.send({ t: 'notice', msg: 'A race is already underway. Wait for the next one.' });
  if (!r.race) { r.race = { st: 'lobby', p: new Map(), lobbyEnds: now() + 30000 }; toRoom(r, { t: 'notice', msg: dn(c.p) + ' opened a street race. Phone > Online > Activities to join.' }); }
  if (r.race.p.size >= 8) return c.send({ t: 'notice', msg: 'The race is full.' });
  r.race.p.set(c.id, { c, cp: -1, last: 0, fin: 0 }); raceBroadcast(r);
}
function raceDrop(r, c) {
  const R = r.race; if (!R || !R.p.has(c.id)) return; R.p.delete(c.id);
  if (!R.p.size) { r.race = null; return; } raceBroadcast(r);
}
function raceCp(c, r, i) {
  const R = r.race, x = R && R.p.get(c.id); if (!x || R.st !== 'running' || x.fin) return;
  const t = now();
  if (i !== x.cp + 1 || i >= RACE_CPS) return c.send({ t: 'deny', label: 'race', why: 'checkpoint out of order' });
  if (t - (x.last || R.startAt) < 900) return c.send({ t: 'deny', label: 'race', why: 'checkpoint too fast' });
  x.cp = i; x.last = t;
  if (i === RACE_CPS - 1) { x.fin = t - R.startAt; R.order.push(x); }
  raceBroadcast(r);
}
function raceTick(r) {
  const R = r.race; if (!R) return; const t = now();
  if (R.st === 'lobby' && t >= R.lobbyEnds) {
    if (R.p.size < 2) { for (const x of R.p.values()) x.c.send({ t: 'notice', msg: 'Race cancelled. Not enough racers.' }); r.race = null; for (const x of R.p.values()) x.c.send({ t: 'race', st: 'idle' }); return; }
    R.st = 'countdown'; R.startAt = t + 6000; R.order = []; raceBroadcast(r);
  } else if (R.st === 'countdown' && t >= R.startAt) { R.st = 'running'; raceBroadcast(r); }
  else if (R.st === 'running') {
    const first = R.order[0];
    if ((R.order.length === R.p.size) || (first && t - (R.startAt + first.fin) > 45000) || t - R.startAt > 300000) {
      const res = []; let place = 1;
      for (const x of R.order) { const prize = RACE_PRIZE[Math.min(place - 1, 3)]; pay(x.c.p, prize, 'Street race (multiplayer) · place ' + place);
        if (place === 1 || true) { const tm = x.fin / 1000; const b = DB.board.race; b.push({ id: x.c.p.id, name: x.c.p.name, t: +tm.toFixed(2) }); }
        if (!x.c.p.bestRace || x.fin / 1000 < x.c.p.bestRace) x.c.p.bestRace = +(x.fin / 1000).toFixed(2);
        res.push({ name: dn(x.c.p), t: +(x.fin / 1000).toFixed(2), place, prize }); place++; }
      for (const x of R.p.values()) if (!x.fin) res.push({ name: dn(x.c.p), t: 0, place: 0, prize: 0 });
      DB.board.race.sort((a, b) => a.t - b.t); DB.board.race = DB.board.race.slice(0, 50); dirty = true;
      for (const x of R.p.values()) x.c.send({ t: 'race', st: 'results', results: res });
      r.race = null;
    }
  }
}

/* ---------- co-op delivery ---------- */
const COOP_ROUTES = [
  { name: 'Bello Pharmacy', pk: { x: 46, z: 19 }, ds: { x: -50, z: 23 } },
  { name: 'Adewale Court', pk: { x: 46, z: 19 }, ds: { x: 30, z: -21 } },
  { name: 'the market', pk: { x: -31, z: -27 }, ds: { x: 46, z: 19 } }
];
const COOP_PAY = 4000;
function coopView(r) {
  const C = r.coop; if (!C) return { t: 'coop', st: 'idle' };
  const tgt = C.route ? (C.st === 'load' ? C.route.pk : C.route.ds) : null;
  return { t: 'coop', st: C.st, host: C.host.id, route: C.route || null, name: C.route ? C.route.name : '', left: C.st === 'lobby' ? 0 : Math.max(0, Math.round((C.endsAt - now()) / 1000)), members: [...C.p.values()].map(c => ({ id: c.id, name: dn(c.p), here: !tgt ? true : near(c, tgt, 14) })) };
}
function near(c, p, d) { return c.pres.x != null && Math.hypot(c.pres.x - p.x, c.pres.z - p.z) < d; }
function coopBroadcast(r) { const v = coopView(r); if (r.coop) for (const c of r.coop.p.values()) c.send(v); }
function coopJoin(c, r) {
  if (r.coop && r.coop.st !== 'lobby') return c.send({ t: 'notice', msg: 'A co-op delivery is already underway.' });
  if (!r.coop) { r.coop = { st: 'lobby', host: c, p: new Map(), hold: 0 }; toRoom(r, { t: 'notice', msg: dn(c.p) + ' is forming a co-op delivery crew. Phone > Online > Activities.' }); }
  if (r.coop.p.size >= 4) return c.send({ t: 'notice', msg: 'The crew is full.' });
  r.coop.p.set(c.id, c); coopBroadcast(r);
}
function coopDrop(r, c) {
  const C = r.coop; if (!C || !C.p.has(c.id)) return; C.p.delete(c.id);
  if (!C.p.size) { r.coop = null; return; }
  if (C.host === c) C.host = C.p.values().next().value;
  if (C.st !== 'lobby' && C.p.size < 2) { for (const m of C.p.values()) m.send({ t: 'coop', st: 'failed', why: 'Your partner left.' }); r.coop = null; return; }
  coopBroadcast(r);
}
function coopStart(c, r) {
  const C = r.coop; if (!C || C.host !== c || C.st !== 'lobby') return;
  if (C.p.size < 2) return c.send({ t: 'notice', msg: 'You need at least two people for a co-op delivery.' });
  C.route = COOP_ROUTES[Math.floor(Math.random() * COOP_ROUTES.length)]; C.st = 'load'; C.endsAt = now() + 120000; C.hold = 0; coopBroadcast(r);
}
function coopTick(r) {
  const C = r.coop; if (!C || C.st === 'lobby') return; const t = now();
  const tgt = C.st === 'load' ? C.route.pk : C.route.ds, all = [...C.p.values()].every(c => near(c, tgt, 14));
  if (t > C.endsAt) { for (const m of C.p.values()) m.send({ t: 'coop', st: 'failed', why: 'Time ran out.' }); r.coop = null; return; }
  if (all) { C.hold += 0.5; if (C.hold >= 2) {
      C.hold = 0;
      if (C.st === 'load') { C.st = 'haul'; C.endsAt = t + 240000; }
      else { for (const m of C.p.values()) { pay(m.p, COOP_PAY, 'Co-op delivery'); m.p.jobs++; m.send({ t: 'coop', st: 'done', pay: COOP_PAY }); } r.coop = null; return; }
    } } else C.hold = 0;
  coopBroadcast(r);
}
setInterval(() => { for (const r of rooms.values()) { raceTick(r); } }, 500);
setInterval(() => { for (const r of rooms.values()) coopTick(r); }, 500);


/* ---------- arcade score boards ---------- */
const ARC_RULES = { pool: { max: 880, sec: 6 }, pen: { max: 1100, sec: 15 }, bike: { max: 1800, sec: 18 }, bee: { max: 2100, sec: 25 } };
function arcTop(g, pid) {
  const rows = Object.entries(DB.board.arc[g] || {}).filter(([id]) => DB.players[id]).sort((a, b) => b[1].score - a[1].score || a[1].at - b[1].at);
  const i = rows.findIndex(([id]) => id === pid);
  return { game: g, board: rows.slice(0, 10).map(([id, v]) => ({ name: DB.players[id].name, score: v.score, me: id === pid })), rank: i < 0 ? 0 : i + 1, best: i < 0 ? 0 : rows[i][1].score, total: rows.length };
}
function arcScore(c, g, s) {
  const R = ARC_RULES[g], p = c.p, deny = why => c.send({ t: 'deny', label: 'score', why });
  s = Math.round(+s); if (!R || !isFinite(s) || s < 0) return;
  const j = c.job; if (!j || j.type !== (g === 'bee' ? 'bee' : 'arcade')) return deny('no active game');
  if (j.scored) return deny('score already sent');
  if ((now() - j.t0) / 1000 < R.sec) return deny('too fast');
  if (s > R.max) return deny('score too high');
  j.scored = true;
  const b = DB.board.arc[g], cur = b[p.id], isBest = !cur || s > cur.score;
  if (isBest) { b[p.id] = { score: s, at: now() }; dirty = true; }
  c.send(Object.assign(arcTop(g, p.id), { t: 'arcboard', got: s, newBest: isBest }));
}

/* ---------- spelling bee (multiplayer) ---------- */
const BEE_LOBBY = +process.env.BEE_LOBBY_MS || 30000, BEE_LEAD = +process.env.BEE_LEAD_MS || 3500, BEE_REVEAL = +process.env.BEE_REVEAL_MS || 4500;
const BEE_N = 8, BEE_SEC = 25, BEE_PTS = { 1: 100, 2: 150, 3: 250 }, BEE_PRIZE = [4000, 2000, 1000], BEE_PART = 300;
function beePick() {
  const by = t => BEE_WORDS.filter(w => w[1] === t).sort(() => Math.random() - .5);
  return [...by(1).slice(0, 3), ...by(2).slice(0, 3), ...by(3).slice(0, 2)].map(w => ({ word: w[0], tier: w[1], def: w[2] }));
}
function beeView(r) {
  const B = r.bee; if (!B) return { t: 'bee', st: 'idle' };
  const players = [...B.p.values()].map(x => ({ id: x.c.id, name: dn(x.c.p), pts: x.pts, ok: x.ok }));
  const v = { t: 'bee', st: B.st, now: now(), players, lobbyEnds: B.lobbyEnds || 0, of: BEE_N, n: B.i + 1 };
  if (B.st === 'word') { const w = B.words[B.i]; Object.assign(v, { word: w.word, def: w.def, tier: w.tier, len: w.word.length, startAt: B.startAt, endsAt: B.endsAt, sec: BEE_SEC, done: [...B.p.values()].filter(x => x.ans !== null).map(x => x.c.id) }); }
  if (B.st === 'reveal') Object.assign(v, { word: B.words[B.i].word, results: B.res, nextAt: B.nextAt });
  return v;
}
function beeBroadcast(r) { const v = beeView(r); if (r.bee) for (const x of r.bee.p.values()) x.c.send(v); }
function beeJoin(c, r) {
  if (r.bee && r.bee.st !== 'lobby') return c.send({ t: 'notice', msg: 'A spelling bee is already underway. Wait for the next one.' });
  if (!r.bee) { r.bee = { st: 'lobby', p: new Map(), i: 0, lobbyEnds: now() + BEE_LOBBY, words: [] }; toRoom(r, { t: 'notice', msg: dn(c.p) + ' opened a spelling bee. Phone > Online > Activities, or the Community Hall stage.' }); }
  if (r.bee.p.size >= 10) return c.send({ t: 'notice', msg: 'The spelling bee is full.' });
  r.bee.p.set(c.id, { c, pts: 0, ok: 0, ans: null, at: 0 }); beeBroadcast(r);
}
function beeDrop(r, c) {
  const B = r.bee; if (!B || !B.p.has(c.id)) return; B.p.delete(c.id);
  if (!B.p.size) { r.bee = null; return; } beeBroadcast(r);
}
function beeNext(r, t) {
  const B = r.bee; B.st = 'word'; B.startAt = t + BEE_LEAD; B.endsAt = B.startAt + BEE_SEC * 1000;
  for (const x of B.p.values()) x.ans = null;
  beeBroadcast(r);
}
function beeAnswer(c, r, text) {
  const B = r.bee, x = B && B.p.get(c.id); if (!x || B.st !== 'word' || x.ans !== null) return;
  const t = now(); if (t < B.startAt - 300 || t > B.endsAt + 800) return;
  x.ans = clean(text, 30).toLowerCase().replace(/[^a-z]/g, ''); x.at = t;
  beeBroadcast(r);
}
function beeTick(r) {
  const B = r.bee; if (!B) return; const t = now();
  if (B.st === 'lobby' && t >= B.lobbyEnds) {
    if (B.p.size < 2) { const all = [...B.p.values()]; r.bee = null; for (const x of all) { x.c.send({ t: 'notice', msg: 'Spelling bee cancelled. Not enough spellers.' }); x.c.send({ t: 'bee', st: 'idle' }); } return; }
    B.words = beePick(); B.i = 0; beeNext(r, t);
  } else if (B.st === 'word') {
    const everyone = [...B.p.values()].every(x => x.ans !== null);
    if ((everyone && t > B.startAt) || t > B.endsAt + 900) {
      const w = B.words[B.i], res = [];
      for (const x of B.p.values()) {
        const ok = x.ans !== null && x.ans === w.word.toLowerCase();
        const left = Math.max(0, Math.min(1, (B.endsAt - x.at) / (BEE_SEC * 1000)));
        const pts = ok ? BEE_PTS[w.tier] + Math.round(50 * left) : 0;
        x.pts += pts; if (ok) x.ok++;
        res.push({ id: x.c.id, name: dn(x.c.p), ans: x.ans || '', ok, pts, total: x.pts });
      }
      B.res = res.sort((a, b) => b.total - a.total); B.st = 'reveal'; B.nextAt = t + BEE_REVEAL; beeBroadcast(r);
    }
  } else if (B.st === 'reveal' && t >= B.nextAt) {
    B.i++;
    if (B.i < BEE_N) return beeNext(r, t);
    const order = [...B.p.values()].sort((a, b) => b.pts - a.pts || b.ok - a.ok), res = [];
    order.forEach((x, k) => {
      let prize = 0; if (x.pts > 0 && k < 3) prize = BEE_PRIZE[k]; else if (x.ok >= 3) prize = BEE_PART;
      if (prize) { pay(x.c.p, prize, 'Spelling bee (multiplayer) · ' + (k < 3 && x.pts > 0 ? 'place ' + (k + 1) : 'participation')); }
      const bs = DB.board.bee[x.c.p.id] = DB.board.bee[x.c.p.id] || { pts: 0, wins: 0, games: 0 };
      bs.pts += x.pts; bs.games++; if (k === 0 && x.pts > 0 && order.length > 1) bs.wins++;
      res.push({ id: x.c.id, name: dn(x.c.p), pts: x.pts, ok: x.ok, place: k + 1, prize });
    });
    dirty = true;
    for (const x of B.p.values()) x.c.send({ t: 'bee', st: 'done', results: res, of: BEE_N });
    r.bee = null;
  }
}
setInterval(() => { for (const r of rooms.values()) beeTick(r); }, 400);

/* ---------- message handling ---------- */
const TOPICS = { chat: 800, emote: 1000, honk: 900, punch: 300 };
const PKEYS = ['x', 'z', 'y', 'cx', 'cz', 'cy', 'd', 'hp', 'pv', 'w', 'ck'];
const CK = new Set(['sedan', 'taxi', 'bus', 'keke', 'moto', 'suv', 'van', 'truck', 'luxury', 'police']);
function cleanPres(pr) {
  const o = {}; if (!pr || typeof pr !== 'object') return o;
  for (const k of ['x', 'z', 'cx', 'cz']) { const v = pr[k]; if (v === null) o[k] = null; else { const n = num(v, 200); if (n !== null) o[k] = +n.toFixed(1); } }
  for (const k of ['y', 'cy']) { const n = num(pr[k], 10); if (n !== null) o[k] = +n.toFixed(2); }
  if (pr.d === 0 || pr.d === 1) o.d = pr.d; if (pr.pv === 0 || pr.pv === 1) o.pv = pr.pv;
  const hp = num(pr.hp, 300); if (hp !== null) o.hp = Math.round(hp);
  const w = num(pr.w, 5); if (w !== null) o.w = Math.round(Math.max(0, w));
  if (typeof pr.ck === 'string' && CK.has(pr.ck)) o.ck = pr.ck;
  return o;
}
function friendList(p) {
  return p.friends.map(id => DB.players[id]).filter(Boolean).map(f => { const c = byPid.get(f.id); return { code: f.code, name: f.name, online: !!c, room: c && c.room ? c.room.name : null, priv: !!(c && c.room && c.room.priv) }; });
}
function crewInfo(p) {
  if (!p.crew) return null; const cr = DB.crews[p.crew.toLowerCase()]; if (!cr) { p.crew = null; return null; }
  const mem = cr.members.map(id => DB.players[id]).filter(Boolean);
  return { name: cr.name, tag: cr.tag, owner: DB.players[cr.owner] ? DB.players[cr.owner].name : '', earned: mem.reduce((a, m) => a + m.earned, 0), members: mem.map(m => ({ name: m.name, online: byPid.has(m.id), earned: m.earned })) };
}
function leaderboards(pid) {
  const ps = Object.values(DB.players);
  const crews = Object.values(DB.crews).map(c => ({ name: c.name, tag: c.tag, earned: c.members.reduce((a, id) => a + ((DB.players[id] || {}).earned || 0), 0) })).sort((a, b) => b.earned - a.earned).slice(0, 10);
  const seen = new Set(), race = [];
  for (const e of DB.board.race) if (!seen.has(e.id)) { seen.add(e.id); race.push({ name: e.name, t: e.t }); if (race.length >= 10) break; }
  const arc = {}; for (const g of ['pool', 'pen', 'bike']) arc[g] = arcTop(g, pid);
  const bee = Object.entries(DB.board.bee).filter(([id]) => DB.players[id]).sort((a, b) => b[1].pts - a[1].pts).slice(0, 10).map(([id, v]) => ({ name: DB.players[id].name, pts: v.pts, wins: v.wins, games: v.games, me: id === pid }));
  const beeSolo = arcTop('bee', pid);
  return { arc, bee, beeSolo, race, earners: ps.sort((a, b) => b.earned - a.earned).slice(0, 10).map(p => ({ name: p.name, earned: p.earned })), crews };
}
function refreshName(c) { if (c.room && c.pres.x != null) toRoom(c.room, { t: 'p', id: c.id, pr: presOut(c) }, c); }

function onMsg(c, m) {
  if (m.t === 'ping') return c.send({ t: 'pong', now: now() });
  if (m.t === 'hello') return hello(c, m);
  if (!c.p) return;
  const p = c.p, r = c.room;
  switch (m.t) {
    case 'pr': {
      if (!r) return; const o = cleanPres(m.pr);
      for (const k of Object.keys(o)) { if (o[k] === null) delete c.pres[k]; else c.pres[k] = o[k]; }
      if (c.pres.x == null) { toRoom(r, { t: 'bye', id: c.id }, c); return; }
      toRoom(r, { t: 'p', id: c.id, pr: presOut(c) }, c); break;
    }
    case 'ev': {
      if (!r || typeof m.topic !== 'string' || !(m.topic in TOPICS) || !c.limit('ev:' + m.topic, TOPICS[m.topic])) return;
      const d = m.data && typeof m.data === 'object' ? m.data : {};
      let out = null;
      if (m.topic === 'chat') {
        if (now() < c.mutedUntil) return c.send({ t: 'notice', msg: 'You are muted for now after player reports.' });
        const text = filt(d.t); if (!text) return; out = { n: dn(p), t: text }; r.chat.push({ who: p.code, name: p.name, t: text, at: now() }); if (r.chat.length > 40) r.chat.shift();
      } else if (m.topic === 'emote') { if (d.k !== 'wave') return; out = { k: 'wave', n: dn(p) }; }
      else if (m.topic === 'honk') { const x = num(d.x, 200), z = num(d.z, 200); if (x === null || z === null) return; out = { x, z }; }
      else if (m.topic === 'punch') {
        const tgt = online.get(String(d.t)); if (!tgt || tgt.room !== r) return;
        if (c.pres.x == null || tgt.pres.x == null || Math.hypot(c.pres.x - tgt.pres.x, c.pres.z - tgt.pres.z) > 5.2) return;
        out = { t: tgt.id, d: Math.max(4, Math.min(16, Math.round(+d.d || 8))) };
      }
      toRoom(r, { t: 'e', id: c.id, topic: m.topic, data: out }, c); break;
    }
    case 'room': {
      if (m.op === 'private') { let code; do code = codeGen(5); while (rooms.has(code)); joinRoom(c, getRoom(code, true)); }
      else if (m.op === 'join') {
        const code = clean(m.code, 8).toUpperCase(); const t = rooms.get(code);
        if (!t || !t.priv) return c.send({ t: 'notice', msg: 'No private session with that code.' });
        if (t.members.size >= MAX_ROOM) return c.send({ t: 'notice', msg: 'That session is full.' }); joinRoom(c, t);
      } else if (m.op === 'friend') {
        const f = DB.byCode[clean(m.code, 8).toUpperCase()], fc = f && byPid.get(f); const fp = DB.players[f];
        if (!fc || !fc.room || !(fp.friends.includes(p.id) || p.friends.includes(fp.id))) return c.send({ t: 'notice', msg: 'Cannot join that friend right now.' });
        if (fc.room.members.size >= MAX_ROOM) return c.send({ t: 'notice', msg: 'Their session is full.' }); joinRoom(c, fc.room);
      } else if (m.op === 'public') joinRoom(c, publicRoom());
      break;
    }
    case 'claim': claim(c, m.label, m.amount); break;
    case 'jobstart': if (['food', 'taxi', 'courier', 'market', 'recover', 'escape', 'race', 'arcade', 'bee'].includes(m.type)) c.job = { type: m.type, t0: now() }; break;
    case 'jobend': c.job = null; break;
    case 'save': if (typeof m.blob === 'string' && m.blob.length < 30000 && c.limit('save', 5000)) { p.blob = m.blob; dirty = true; } break;
    case 'friend': {
      if (m.op === 'list') return c.send({ t: 'friends', list: friendList(p) });
      const f = DB.byCode[clean(m.code, 8).toUpperCase()];
      if (m.op === 'add') { if (!f || f === p.id) return c.send({ t: 'notice', msg: 'No player with that ID.' }); if (!p.friends.includes(f) && p.friends.length < 50) p.friends.push(f); dirty = true; const fc = byPid.get(f); if (fc) fc.send({ t: 'notice', msg: p.name + ' added you as a friend.' }); }
      else if (m.op === 'remove') { p.friends = p.friends.filter(x => x !== f); dirty = true; }
      c.send({ t: 'friends', list: friendList(p) }); break;
    }
    case 'crew': {
      const op = m.op;
      if (op === 'info') return c.send({ t: 'crew', crew: crewInfo(p) });
      if (op === 'create') {
        if (p.crew) return c.send({ t: 'notice', msg: 'Leave your crew first.' });
        const name = clean(m.name, 16).replace(/\s+/g, ' ').trim(), tag = clean(m.tag, 4).toUpperCase();
        if (!/^[A-Za-z0-9 ]{3,16}$/.test(name) || !/^[A-Z0-9]{2,4}$/.test(tag) || BAD.test(name + tag)) { BAD.lastIndex = 0; return c.send({ t: 'notice', msg: 'Crew name 3-16 letters or numbers, tag 2-4.' }); } BAD.lastIndex = 0;
        if (DB.crews[name.toLowerCase()]) return c.send({ t: 'notice', msg: 'That crew name is taken.' });
        if (p.money < 2500) return c.send({ t: 'notice', msg: 'Starting a crew costs ₦2,500.' });
        pay(p, -2500, 'Crew registration'); DB.crews[name.toLowerCase()] = { name, tag, owner: p.id, members: [p.id], created: now() }; p.crew = name; dirty = true;
      } else if (op === 'join') {
        const cr = DB.crews[clean(m.name, 16).trim().toLowerCase()];
        if (p.crew) return c.send({ t: 'notice', msg: 'Leave your crew first.' });
        if (!cr || cr.members.length >= 12) return c.send({ t: 'notice', msg: 'Crew not found or full.' });
        cr.members.push(p.id); p.crew = cr.name; dirty = true;
      } else if (op === 'leave') {
        const cr = p.crew && DB.crews[p.crew.toLowerCase()];
        if (cr) { cr.members = cr.members.filter(x => x !== p.id); if (!cr.members.length) delete DB.crews[cr.name.toLowerCase()]; else if (cr.owner === p.id) cr.owner = cr.members[0]; }
        p.crew = null; dirty = true;
      }
      refreshName(c); c.send({ t: 'crew', crew: crewInfo(p) }); break;
    }
    case 'crewchat': {
      if (!p.crew || !c.limit('cc', 700) || now() < c.mutedUntil) return; const text = filt(m.text); if (!text) return; const cr = DB.crews[p.crew.toLowerCase()]; if (!cr) return;
      for (const id of cr.members) { const o = byPid.get(id); if (o) o.send({ t: 'crewmsg', n: p.name, text }); } break;
    }
    case 'report': {
      const tgt = online.get(String(m.id)); if (!tgt || !tgt.p || tgt === c || !c.limit('report', 5000)) return;
      const rep = { at: now(), from: p.code, target: tgt.p.code, name: tgt.p.name, reason: clean(m.reason, 80), chat: (r ? r.chat.slice(-10) : []) };
      DB.reports.push(rep); if (DB.reports.length > 300) DB.reports.shift(); dirty = true;
      tgt.reps = (tgt.reps || []).filter(x => now() - x.at < 600000); if (!tgt.reps.some(x => x.by === p.code)) tgt.reps.push({ at: now(), by: p.code });
      if (tgt.reps.length >= 3) { tgt.mutedUntil = now() + 600000; tgt.send({ t: 'notice', msg: 'You have been muted for 10 minutes after several player reports.' }); }
      c.send({ t: 'notice', msg: 'Report sent. Thank you.' }); break;
    }
    case 'race': if (!r) return; if (m.op === 'join') raceJoin(c, r); else if (m.op === 'leave') { raceDrop(r, c); c.send({ t: 'race', st: 'idle' }); } else if (m.op === 'cp') raceCp(c, r, m.i | 0); else if (m.op === 'state') c.send(raceView(r)); break;
    case 'coop': if (!r) return; if (m.op === 'join') coopJoin(c, r); else if (m.op === 'leave') { coopDrop(r, c); c.send({ t: 'coop', st: 'idle' }); } else if (m.op === 'start') coopStart(c, r); else if (m.op === 'state') c.send(coopView(r)); break;
    case 'name': { const n = goodName(m.name); if (n && n !== p.name && c.limit('name', 3000)) { p.name = n; dirty = true; refreshName(c); } break; }
    case 'lb': c.send({ t: 'lb', lb: leaderboards(c.p.id) }); break;
    case 'score': arcScore(c, String(m.game), m.score); break;
    case 'arcb': { const g = String(m.game); if (ARC_RULES[g] && c.limit('arcb', 400)) c.send(Object.assign(arcTop(g, p.id), { t: 'arcboard' })); break; }
    case 'bee': if (!r) return; if (m.op === 'join') beeJoin(c, r); else if (m.op === 'leave') { beeDrop(r, c); c.send({ t: 'bee', st: 'idle' }); } else if (m.op === 'ans') { if (c.limit('bee:ans', 250)) beeAnswer(c, r, m.text); } else if (m.op === 'state') c.send(beeView(r)); break;
  }
}

function hello(c, m) {
  if (c.p) return;
  let p = null, tok = null, rkPlain = null;
  if (typeof m.token === 'string' && m.token.length >= 16) { const id = DB.byTok[sha(m.token)]; p = id && DB.players[id]; }
  if (!p && m.code && m.rk) { const id = DB.byCode[clean(m.code, 8).toUpperCase()], q = id && DB.players[id]; if (q && q.rk === sha(clean(m.rk, 12).toUpperCase())) { p = q; delete DB.byTok[p.th]; tok = rid(32); p.th = sha(tok); DB.byTok[p.th] = p.id; dirty = true; } }
  const name = goodName(m.name);
  if (!p) { const np = newPlayer(name || ('Player' + (10 + Math.floor(Math.random() * 90)))); p = np.p; tok = np.tok; rkPlain = np.rkPlain; }
  else if (name && name !== p.name) { p.name = name; dirty = true; }
  if (DB.bans[p.id]) { c.send({ t: 'notice', msg: 'This account is suspended.' }); return c.kill(); }
  const old = byPid.get(p.id); if (old && old !== c) { old.send({ t: 'notice', msg: 'Signed in from another device.' }); old.kill(); }
  c.p = p; online.set(c.id, c); byPid.set(p.id, c); p.seen = now(); dirty = true;
  let room = null;
  if (m.room) { const t = rooms.get(clean(m.room, 8).toUpperCase()); if (t && t.priv && t.members.size < MAX_ROOM) room = t; }
  c.send({ t: 'welcome', id: c.id, code: p.code, name: p.name, money: p.money, blob: p.blob, earned: p.earned, jobs: p.jobs, bestRace: p.bestRace, token: tok, rk: rkPlain, crew: crewInfo(p), now: now(), max: MAX_ROOM });
  joinRoom(c, room || publicRoom());
}

/* ---------- HTTP: static files, health, admin ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.css': 'text/css', '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain' };
const server = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname === '/health') { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ ok: true, online: online.size, rooms: rooms.size })); }
  if (u.pathname.startsWith('/admin/')) {
    if (!ADMIN_KEY || u.searchParams.get('key') !== ADMIN_KEY) { res.writeHead(403); return res.end('forbidden'); }
    res.writeHead(200, { 'content-type': 'application/json' });
    if (u.pathname === '/admin/state') return res.end(JSON.stringify({ online: [...online.values()].map(c => ({ id: c.id, code: c.p.code, name: c.p.name, room: c.room && c.room.name, money: c.p.money })), rooms: [...rooms.values()].map(r => ({ name: r.name, n: r.members.size, race: r.race && r.race.st, coop: r.coop && r.coop.st, bee: r.bee && r.bee.st })), reports: DB.reports.slice(-50), players: Object.keys(DB.players).length }));
    if (u.pathname === '/admin/kick') { const c = [...online.values()].find(x => x.p.code === u.searchParams.get('code')); if (c) c.kill(); return res.end('{"ok":true}'); }
    if (u.pathname === '/admin/ban') { const id = DB.byCode[u.searchParams.get('code')]; if (id) { DB.bans[id] = 1; dirty = true; const c = byPid.get(id); if (c) c.kill(); } return res.end('{"ok":true}'); }
    return res.end('{}');
  }
  let f = path.normalize(path.join(PUB, u.pathname === '/' ? 'index.html' : u.pathname));
  if (!f.startsWith(PUB)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (e, d) => { if (e) { res.writeHead(404); return res.end('Aketown server is running. Put the game files in ./public to serve them here.'); } res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream', 'cache-control': 'no-cache' }); res.end(d); });
});
server.on('upgrade', (req, sock) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { sock.destroy(); return; }
  if (online.size > 400) { sock.write('HTTP/1.1 503 Service Unavailable\r\n\r\n'); sock.destroy(); return; }
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + crypto.createHash('sha1').update(key + GUID).digest('base64') + '\r\n\r\n');
  sock.setNoDelay(true); new Conn(sock);
});
setInterval(() => { for (const c of online.values()) c.raw(9, Buffer.alloc(0)); }, 25000);
if (require.main === module) server.listen(PORT, () => console.log('Aketown server on :' + PORT));
module.exports = { server, DB };
