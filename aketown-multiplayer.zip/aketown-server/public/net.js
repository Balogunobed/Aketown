/* Aketown online adapter.
   The game was written against a small "room" API (presence, emit/on, peers).
   This file provides that same API on top of Supabase Realtime broadcast, so
   anyone with the link can play together with no login.
   Without a Supabase URL and key in config.js the game runs single-player. */
(function () {
  'use strict';
  var cfg = window.AKETOWN_NET || {};
  var NICK_KEY = 'aketown.nick';
  window.AKETOWN_NICK = function () {
    try { return (localStorage.getItem(NICK_KEY) || '').trim().slice(0, 20); } catch (e) { return ''; }
  };

  // name field on the menu
  var nickIn = document.getElementById('nickIn');
  if (nickIn) {
    nickIn.value = window.AKETOWN_NICK();
    nickIn.addEventListener('input', function () {
      try { localStorage.setItem(NICK_KEY, nickIn.value.slice(0, 20)); } catch (e) {}
      clearTimeout(nickIn._t); nickIn._t = setTimeout(function () { if (typeof wsSend === 'function' && connected) wsSend({ t: 'name', name: nickIn.value }); }, 800);
    });
  }

  function rid() {
    var a = 'abcdefghijklmnopqrstuvwxyz0123456789', s = '';
    for (var i = 0; i < 12; i++) s += a[Math.floor(Math.random() * a.length)];
    return s;
  }
  var srvMode = !!cfg.server;
  var enabled = srvMode || !!(cfg.url && cfg.anonKey && window.supabase && window.supabase.createClient);
  var me = rid();
  var mine = {}, peers = {}, handlers = {}, peerListeners = [], connListeners = [];
  var snapshot = Object.freeze([]), connected = false, dirty = false, lastSend = 0, channel = null, notifyQueued = false;
  var joinedBuf = [], leftBuf = [], updatedBuf = [], pend = {};

  function rebuild() {
    var list = [{ peer: me, by: null, isMe: true, sameTab: true, kind: 'viewer', guest: false, presence: Object.freeze(Object.assign({}, mine)), updatedAt: Date.now() }];
    for (var k in peers) list.push(peers[k].view);
    snapshot = Object.freeze(list);
  }
  function queueNotify() {
    if (notifyQueued) return;
    notifyQueued = true;
    requestAnimationFrame(function () {
      notifyQueued = false;
      var ch = { peers: snapshot, joined: joinedBuf, left: leftBuf, updated: updatedBuf };
      joinedBuf = []; leftBuf = []; updatedBuf = [];
      peerListeners.slice().forEach(function (f) { try { f(ch); } catch (e) {} });
    });
  }
  function validId(s) { return typeof s === 'string' && /^[a-z0-9]{6,24}$/.test(s); }

  function applyPresence(id, pr) {
    if (!validId(id) || id === me || !pr || typeof pr !== 'object') return;
    var txt; try { txt = JSON.stringify(pr); } catch (e) { return; }
    if (txt.length > 1200) return;
    var existing = peers[id];
    var view = Object.freeze({ peer: id, by: null, isMe: false, sameTab: false, kind: 'viewer', guest: false, presence: Object.freeze(pr), updatedAt: Date.now() });
    peers[id] = { view: view, seen: Date.now() };
    (existing ? updatedBuf : joinedBuf).push(view);
    rebuild(); queueNotify();
  }
  function dropPeer(id) {
    if (!peers[id]) return;
    leftBuf.push(peers[id].view); delete peers[id]; rebuild(); queueNotify();
  }

  function dispatch(topic, data, from, isMe) {
    var list = handlers[topic]; if (!list) return;
    var msg = { topic: topic, data: data, peer: from, by: null, isMe: isMe, sameTab: isMe, kind: 'viewer', guest: false };
    list.slice().forEach(function (f) { try { f(msg); } catch (e) {} });
  }

  var room = {
    emit: function (topic, data) {
      if (!/^[a-z][a-z0-9_.-]{0,47}$/.test(topic)) return Promise.reject({ code: 'invalid_argument', message: 'bad topic' });
      var txt = JSON.stringify(data === undefined ? null : data);
      if (txt.length > 4000) return Promise.reject({ code: 'invalid_argument', message: 'too large' });
      dispatch(topic, data, me, true);
      if (srvMode) { if (connected) wsSend({ t: 'ev', topic: topic, data: data }); }
      else if (channel && connected) channel.send({ type: 'broadcast', event: 'e', payload: { id: me, topic: topic, data: data } });
      return Promise.resolve();
    },
    on: function (topic, fn) {
      (handlers[topic] = handlers[topic] || []).push(fn);
      return function () { var l = handlers[topic] || []; var i = l.indexOf(fn); if (i >= 0) l.splice(i, 1); };
    },
    presence: function (patch) {
      for (var k in patch) { pend[k] = patch[k]; if (patch[k] === null) delete mine[k]; else mine[k] = patch[k]; }
      dirty = true; rebuild(); return Promise.resolve();
    },
    peers: function () { return snapshot; },
    onPeers: function (fn) { peerListeners.push(fn); return function () { var i = peerListeners.indexOf(fn); if (i >= 0) peerListeners.splice(i, 1); }; },
    connected: function () { return connected; },
    onConnection: function (fn) { connListeners.push(fn); setTimeout(function () { fn(connected); }, 0); return function () { var i = connListeners.indexOf(fn); if (i >= 0) connListeners.splice(i, 1); }; },
    join: function () { return Promise.resolve(room); },
    leave: function () { return Promise.resolve(); },
    sendToClaudeSession: function () { return Promise.reject({ code: 'claude_unavailable', message: 'n/a' }); },
    canSendToClaudeSession: function () { return Promise.resolve('off'); }
  };

  var userNs = {
    isOwner: function () { return Promise.resolve(false); },
    canEdit: function () { return Promise.resolve(false); },
    can: function () { return Promise.resolve(null); },
    id: function () { return Promise.resolve(null); },
    me: function () { return Promise.resolve({ id: null, name: window.AKETOWN_NICK(), avatarUrl: '', color: '#f4b81c', email: null, isOwner: false, canEdit: false }); },
    profiles: function (ids) { var o = {}; [].concat(ids).forEach(function (i) { o[i] = { id: i, name: '', avatarUrl: '', color: '#888', email: null, isMe: false, guest: false }; }); return Promise.resolve(o); },
    name: function () { return Promise.resolve(window.AKETOWN_NICK()); },
    search: function () { return Promise.resolve([]); }
  };

  /* ---- own server (accounts, authoritative money, races, crews) ---- */
  var SRV = window.AKETOWN_SRV = null, ws = null, wsTry = 0, wsHandlers = {}, wsQueue = [];
  function wsSend(o) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); }
  function wsUrl() {
    var s = cfg.server; if (s === 'auto') return (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
    return s;
  }
  function lsg(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }
  function lss(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function wsFire(t, m) { (wsHandlers[t] || []).slice().forEach(function (f) { try { f(m); } catch (e) { if (window.console) console.error(e); } }); }
  function setConn(ok) { if (ok !== connected) { connected = ok; SRV.connected = ok; connListeners.slice().forEach(function (f) { try { f(connected); } catch (e) {} }); wsFire('conn', { ok: ok }); } }
  function wsOpen() {
    var sock;
    try { sock = new WebSocket(wsUrl()); } catch (e) { return setTimeout(wsOpen, 5000); }
    ws = sock;
    sock.onopen = function () {
      wsTry = 0; var q = {}; try { q = new URLSearchParams(location.search); } catch (e) {}
      var hello = { t: 'hello', token: lsg('aketown.token'), name: window.AKETOWN_NICK(), room: q.get ? (q.get('room') || '') : '' };
      var rec = SRV.recover; if (rec) { hello.code = rec.code; hello.rk = rec.rk; hello.token = ''; SRV.recover = null; }
      sock.send(JSON.stringify(hello));
    };
    sock.onmessage = function (e) {
      var m; try { m = JSON.parse(e.data); } catch (x) { return; }
      switch (m.t) {
        case 'welcome':
          if (m.token) lss('aketown.token', m.token);
          me = m.id; SRV.id = m.id; SRV.profile = m; SRV.off = (m.now || Date.now()) - Date.now(); setConn(true); dirty = true; wsFire('welcome', m); break;
        case 'room':
          for (var k in peers) dropPeer(k);
          (m.peers || []).forEach(function (p) { applyPresence(p.id, p.pr); });
          SRV.room = { name: m.name, priv: m.priv, code: m.code, n: m.n }; dirty = true; wsFire('room', m); break;
        case 'p': applyPresence(m.id, m.pr); break;
        case 'bye': dropPeer(m.id); break;
        case 'e': if (validId(m.id) && typeof m.topic === 'string') dispatch(m.topic, m.data, m.id, false); break;
        default: wsFire(m.t, m);
      }
    };
    sock.onclose = function () { setConn(false); SRV.profile = null; wsTry++; setTimeout(wsOpen, Math.min(15000, 800 * Math.pow(2, wsTry))); };
    sock.onerror = function () { try { sock.close(); } catch (e) {} };
  }
  if (srvMode) {
    SRV = window.AKETOWN_SRV = { connected: false, profile: null, id: null, room: null, off: 0, recover: null,
      on: function (t, fn) { (wsHandlers[t] = wsHandlers[t] || []).push(fn); },
      send: wsSend, close: function () { if (ws) try { ws.close(); } catch (e) {} }, now: function () { return Date.now() + SRV.off; } };
    wsOpen();
    setInterval(function () {
      if (!connected) return; var now = Date.now();
      if (dirty || now - lastSend > 2500) {
        if (mine.x === undefined && !dirty && now - lastSend < 2500) return;
        var out = pend; pend = {}; dirty = false; lastSend = now;
        if (Object.keys(out).length || mine.x !== undefined) wsSend({ t: 'pr', pr: Object.keys(out).length ? out : mine });
      }
    }, 200);
    setInterval(function () { if (connected) wsSend({ t: 'ping' }); }, 20000);
  }
  if (enabled && !srvMode) {
    var sb = window.supabase.createClient(cfg.url, cfg.anonKey, { realtime: { params: { eventsPerSecond: 20 } }, auth: { persistSession: false } });
    channel = sb.channel('aketown:' + (cfg.room || 'lobby'), { config: { broadcast: { self: false, ack: false } } });
    channel.on('broadcast', { event: 'p' }, function (m) {
      var p = m && m.payload; if (!p) return;
      if (p.bye) { dropPeer(p.id); return; }
      applyPresence(p.id, p.pr);
    });
    channel.on('broadcast', { event: 'e' }, function (m) {
      var p = m && m.payload; if (!p || !validId(p.id) || p.id === me) return;
      if (typeof p.topic !== 'string' || !/^[a-z][a-z0-9_.-]{0,47}$/.test(p.topic)) return;
      dispatch(p.topic, p.data, p.id, false);
    });
    channel.subscribe(function (status) {
      var ok = status === 'SUBSCRIBED';
      if (ok !== connected) { connected = ok; connListeners.slice().forEach(function (f) { try { f(connected); } catch (e) {} }); }
    });
    // send presence at most 5 times a second, with a keepalive every 2.5 s
    setInterval(function () {
      if (!connected) return;
      var now = Date.now();
      if (mine.x === undefined && !dirty) return;
      if (dirty || now - lastSend > 2500) {
        dirty = false; lastSend = now;
        channel.send({ type: 'broadcast', event: 'p', payload: { id: me, pr: mine } });
      }
    }, 200);
    // forget players who went quiet
    setInterval(function () {
      var now = Date.now();
      for (var k in peers) if (now - peers[k].seen > 7000) dropPeer(k);
    }, 1000);
    window.addEventListener('pagehide', function () {
      try { if (channel && connected) channel.send({ type: 'broadcast', event: 'p', payload: { id: me, bye: true } }); } catch (e) {}
    });
  }

  window.claude = {
    use: function (name) {
      if (name === 'room') return Promise.resolve(enabled ? room : null);
      if (name === 'user') return Promise.resolve(userNs);
      return Promise.resolve(null);
    }
  };
})();
