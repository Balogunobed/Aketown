window.AKETOWN_NET={server:'auto'};
