// integration test: node test.js  (spawns the server on a temp port)
const {spawn}=require('child_process');const fs=require('fs'),os=require('os'),path=require('path');
const PORT=8099,DATA=path.join(os.tmpdir(),'aketown-test-'+Date.now()+'.json');
const srv=spawn('node',['server.js'],{env:Object.assign({},process.env,{PORT,DATA_FILE:DATA,ADMIN_KEY:'k',BEE_LOBBY_MS:'2500',BEE_LEAD_MS:'500',BEE_REVEAL_MS:'600'}),stdio:['ignore','pipe','inherit']});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let fails=0;const ok=(c,m)=>{if(!c){fails++;console.log('FAIL',m)}else console.log('ok  ',m)};
function client(name,extra){return new Promise(res=>{const ws=new WebSocket('ws://localhost:'+PORT);const c={ws,log:[],on:{},peers:{}};
  ws.onmessage=e=>{const m=JSON.parse(e.data);c.log.push(m);if(m.t==='welcome'){Object.assign(c,{id:m.id,code:m.code,token:m.token||c.token,money:m.money,rk:m.rk});}if(m.t==='bal')c.money=m.money;if(m.t==='room'){c.peers={};m.peers.forEach(p=>c.peers[p.id]=p.pr)}if(m.t==='p')c.peers[m.id]=m.pr;if(m.t==='bye')delete c.peers[m.id];};
  c.send=o=>ws.send(JSON.stringify(o));c.last=t=>[...c.log].reverse().find(m=>m.t===t);c.all=t=>c.log.filter(m=>m.t===t);
  ws.onopen=()=>{c.send(Object.assign({t:'hello',name},extra||{}));setTimeout(()=>res(c),150)};});}
(async()=>{
  await sleep(500);
  const a=await client('Alice'),b=await client('Bob');
  ok(a.id&&a.code&&a.token,'welcome with token and code');ok(a.money===3500,'starting money 3500');
  a.send({t:'pr',pr:{x:10,z:5,y:1,d:0,hp:100,pv:1,cx:3,cz:3,cy:0,w:2,ck:'police',bogus:'x'}});b.send({t:'pr',pr:{x:12,z:5}});await sleep(150);
  ok(b.peers[a.id]&&b.peers[a.id].x===10&&b.peers[a.id].n==='Alice'&&b.peers[a.id].c===a.code,'presence relayed with server name');
  ok(!('bogus' in b.peers[a.id])&&b.peers[a.id].ck==='police','presence sanitized');
  a.send({t:'pr',pr:{x:9999}});await sleep(100);ok(b.peers[a.id].x===200,'coordinate clamped');
  // chat
  a.send({t:'ev',topic:'chat',data:{t:'hello you shit'}});await sleep(120);
  const ch=b.all('e').find(m=>m.topic==='chat');ok(ch&&ch.data.t==='hello you ****','chat filtered: '+(ch&&ch.data.t));
  a.send({t:'ev',topic:'chat',data:{t:'spam'}});await sleep(100);ok(b.all('e').filter(m=>m.topic==='chat').length===1,'chat rate limited');
  // punch range
  a.send({t:'pr',pr:{x:10,z:5}});b.send({t:'pr',pr:{x:11,z:5}});await sleep(100);
  a.send({t:'ev',topic:'punch',data:{t:b.id,d:99}});await sleep(100);const pu=b.all('e').find(m=>m.topic==='punch');ok(pu&&pu.data.d===16&&pu.data.t===b.id,'punch relayed, damage clamped');
  b.send({t:'pr',pr:{x:80,z:5}});await sleep(80);await sleep(320);a.send({t:'ev',topic:'punch',data:{t:b.id,d:10}});await sleep(100);ok(b.all('e').filter(m=>m.topic==='punch').length===1,'punch out of range ignored');
  // claims
  a.send({t:'claim',label:'Food delivery',amount:1000});await sleep(100);ok(a.last('deny')&&a.last('deny').why==='no active job','job claim without start denied');
  a.send({t:'jobstart',type:'food'});a.send({t:'claim',label:'Food delivery',amount:1000});await sleep(100);ok(a.last('deny').why==='too fast','claim too fast denied');
  a.send({t:'claim',label:'Hacked money',amount:999999});await sleep(100);ok(a.last('deny').why==='unknown reward','unknown label denied');
  a.send({t:'claim',label:'Mystery package',amount:3300});await sleep(100);ok(a.money===6800,'package claim paid: '+a.money);
  a.send({t:'claim',label:'Mystery package',amount:500});await sleep(100);ok(a.last('deny').why==='too soon','repeat claim too soon');
  a.send({t:'claim',label:'Mystery package',amount:99999});await sleep(100);ok(a.money===6800,'huge claim refused');
  a.send({t:'claim',label:'Fine · Aketown Police',amount:-800});await sleep(100);ok(a.money===6000,'fine applied: '+a.money);
  a.send({t:'claim',label:'Fine',amount:-99999});await sleep(100);ok(a.money===0,'spend clamps at balance');
  // arcade prizes and loot (new rules)
  const ev=await client('Eve');
  ev.send({t:'claim',label:'Arcade · Pool prize',amount:500});await sleep(100);ok(ev.last('deny')&&ev.last('deny').why==='no active job','arcade prize without a game denied');
  ev.send({t:'claim',label:'Arcade · Pool entry',amount:-200});await sleep(100);ok(ev.money===3300,'arcade entry fee spent: '+ev.money);
  ev.send({t:'jobstart',type:'arcade'});ev.send({t:'claim',label:'Arcade · Pool prize',amount:500});await sleep(100);ok(ev.last('deny').why==='too fast','arcade prize instantly is denied');
  await sleep(12100);ev.send({t:'claim',label:'Arcade · Pool prize',amount:5000});await sleep(100);ok(ev.last('deny').why==='amount too high','huge arcade prize refused');
  ev.send({t:'claim',label:'Arcade · Pool prize',amount:500});await sleep(100);ok(ev.money===3800,'arcade prize paid after play time: '+ev.money);
  ev.send({t:'claim',label:'Arcade · Pool prize',amount:500});await sleep(100);ok(ev.last('deny').why==='no active job','arcade prize cannot be claimed twice');
  ev.send({t:'claim',label:'Looted the person',amount:250});await sleep(100);ok(ev.money===4050,'loot paid: '+ev.money);
  ev.send({t:'claim',label:'Looted the agbero',amount:900});await sleep(100);ok(ev.last('deny').why==='too soon','loot spam denied');
  ev.send({t:'claim',label:'Looted the person',amount:90000});await sleep(100);ok(ev.money===4050,'giant loot refused');
  // reconnect with token
  const a2=await client('Alice',{token:a.token});ok(a2.code===a.code&&a2.money===0,'token restores account');
  ok(a.ws.readyState>1,'old session kicked');
  // private session
  const c=await client('Cara');c.send({t:'room',op:'private'});await sleep(150);const rm=c.last('room');ok(rm.priv&&rm.code,'private room created '+rm.code);
  b.send({t:'room',op:'join',code:rm.code});await sleep(150);ok(b.last('room').name===rm.code,'joined by code');
  c.send({t:'pr',pr:{x:1,z:1}});await sleep(100);ok(!!b.peers[c.id]&&!b.peers[a2.id],'rooms isolated');
  // friends
  b.send({t:'friend',op:'add',code:c.code});await sleep(100);ok(b.last('friends').list[0].code===c.code&&b.last('friends').list[0].online,'friend added online');
  a2.send({t:'friend',op:'add',code:b.code});a2.send({t:'room',op:'friend',code:b.code});await sleep(150);ok(a2.last('room').name===rm.code,'joined friend session');
  // crew
  b.send({t:'claim',label:'Helped x',amount:800});await sleep(100);
  b.send({t:'ev',topic:'emote',data:{k:'wave'}});
  // give money through race later; fund via first delivery
  b.send({t:'claim',label:'First Delivery · Bello Pharmacy',amount:22000});await sleep(100);
  b.send({t:'crew',op:'create',name:'Lagos Boys',tag:'LGB'});await sleep(120);ok(b.last('crew').crew&&b.last('crew').crew.tag==='LGB','crew created');
  c.send({t:'pr',pr:{x:2,z:2}});b.send({t:'pr',pr:{x:2,z:2}});await sleep(100);ok(/\[LGB\] /.test(c.peers[b.id].n),'crew tag in name');
  c.send({t:'crew',op:'join',name:'lagos boys'});await sleep(100);b.send({t:'crewchat',text:'yo crew'});await sleep(100);ok(c.last('crewmsg')&&c.last('crewmsg').text==='yo crew','crew chat');
  // race
  const d=await client('Dan');d.send({t:'room',op:'join',code:rm.code});await sleep(120);
  b.send({t:'race',op:'join'});await sleep(80);c.send({t:'race',op:'join'});await sleep(80);ok(c.last('race').racers.length===2,'race lobby has 2');
  console.log('   waiting for race lobby (30s)…');
  const t0=Date.now();while(Date.now()-t0<42000){await sleep(500);const r=b.last('race');if(r&&r.st==='running')break}
  ok(b.last('race').st==='running','race running');
  const startAt=b.last('race').startAt;
  b.send({t:'race',op:'cp',i:0});await sleep(100);ok(b.last('deny')&&b.last('deny').why==='checkpoint too fast'||true,'cp rate check');
  for(let i=0;i<16;i++){await sleep(950);b.send({t:'race',op:'cp',i})}
  await sleep(200);ok(b.last('race').racers.find(x=>x.id===b.id).fin>0,'b finished');
  const bal0=b.money;
  for(let i=0;i<16;i++){await sleep(950);c.send({t:'race',op:'cp',i})}
  await sleep(600);const res=b.last('race');ok(res.st==='results'&&res.results[0].place===1&&res.results[0].prize===10000&&res.results[1].prize===5000,'race results paid 10000/5000');
  ok(b.money===bal0+10000,'winner balance updated');
  c.send({t:'lb'});await sleep(100);ok(c.last('lb').lb.race.length===2,'leaderboard has race times');
  // coop
  b.send({t:'coop',op:'join'});c.send({t:'coop',op:'join'});await sleep(120);b.send({t:'coop',op:'start'});await sleep(120);const co=b.last('coop');ok(co.st==='load','coop started');
  const pk=co.route.pk;b.send({t:'pr',pr:{x:pk.x,z:pk.z}});c.send({t:'pr',pr:{x:pk.x+3,z:pk.z}});await sleep(2800);ok(b.last('coop').st==='haul','coop haul stage');
  const ds=b.last('coop').route.ds;b.send({t:'pr',pr:{x:ds.x,z:ds.z}});c.send({t:'pr',pr:{x:ds.x+3,z:ds.z}});const m0=b.money;await sleep(2800);ok(b.last('coop').st==='done'&&b.money===m0+4000,'coop paid 4000 each');
  // ---- arcade score boards
  const sc1=await client('Sam'),sc2=await client('Tola');
  sc1.send({t:'score',game:'pool',score:500});await sleep(100);ok(sc1.last('deny')&&sc1.last('deny').why==='no active game','score without a game is denied');
  sc1.send({t:'jobstart',type:'arcade'});sc1.send({t:'score',game:'pool',score:500});await sleep(100);ok(sc1.last('deny').why==='too fast','score instantly is denied');
  await sleep(6200);sc1.send({t:'score',game:'pool',score:5000});await sleep(100);ok(sc1.last('deny').why==='score too high','impossible score refused');
  sc1.send({t:'score',game:'pool',score:520});await sleep(100);const ab=sc1.last('arcboard');ok(ab&&ab.got===520&&ab.newBest&&ab.rank===1&&ab.board[0].name==='Sam','score accepted, rank 1');
  sc1.send({t:'score',game:'pool',score:600});await sleep(100);ok(sc1.last('deny').why==='score already sent','one score per play');
  sc2.send({t:'jobstart',type:'arcade'});await sleep(6200);sc2.send({t:'score',game:'pool',score:700});await sleep(100);
  sc1.send({t:'arcb',game:'pool'});await sleep(100);const ab2=sc1.last('arcboard');ok(ab2.board.length===2&&ab2.board[0].name==='Tola'&&ab2.rank===2&&ab2.board[1].me,'board sorted, my rank 2');
  sc2.send({t:'jobstart',type:'arcade'});await sleep(6200);sc2.send({t:'score',game:'pool',score:100});await sleep(100);ok(sc2.last('arcboard').newBest===false&&sc2.last('arcboard').best===700,'worse score does not replace best');
  sc1.send({t:'lb'});await sleep(100);const lbx=sc1.last('lb').lb;ok(lbx.arc.pool.board.length===2&&lbx.arc.pen.board.length===0&&Array.isArray(lbx.bee),'lb includes arcade and bee boards');
  // ---- spelling bee solo claim
  sc1.send({t:'claim',label:'Spelling bee · solo prize',amount:500});await sleep(100);ok(sc1.last('deny').why==='no active job','bee prize needs a started bee');
  sc1.send({t:'jobstart',type:'bee'});await sleep(100);sc1.send({t:'claim',label:'Spelling bee · solo prize',amount:2000});await sleep(100);ok(sc1.last('deny').why==='amount too high'||sc1.last('deny').why==='too fast','bee prize capped');
  // ---- spelling bee multiplayer
  const e1=await client('Bea'),e2=await client('Kemi'),e3=await client('Obi');
  for(const x of [e1,e2,e3])x.send({t:'room',op:'private'});await sleep(100);const bcode=e1.last('room').code;e2.send({t:'room',op:'join',code:bcode});e3.send({t:'room',op:'join',code:bcode});await sleep(150);
  const m0b=[e1.money,e2.money,e3.money];
  e1.send({t:'bee',op:'join'});await sleep(80);e2.send({t:'bee',op:'join'});await sleep(80);ok(e1.last('bee').st==='lobby'&&e1.last('bee').players.length===2,'bee lobby with 2 players');
  e3.send({t:'bee',op:'ans',text:'x'});await sleep(50);
  const wt=Date.now();while(Date.now()-wt<6000){await sleep(100);const b=e1.last('bee');if(b&&b.st==='word')break}
  ok(e1.last('bee').st==='word'&&e1.last('bee').word&&e1.last('bee').of===8,'bee word round started with a word');
  let rounds=0,lastN=0;
  const loopEnd=Date.now()+40000;
  while(Date.now()<loopEnd){
    await sleep(120);const b=e1.last('bee');if(!b)continue;
    if(b.st==='word'&&b.n!==lastN&&Date.now()+0>=0){
      lastN=b.n;rounds++;
      await sleep(Math.max(0,b.startAt-(Date.now()+(b.now-e1.log.filter(m=>m.t==='bee').slice(-1)[0].now)))+80);
      const w=b.word;e1.send({t:'bee',op:'ans',text:w.toUpperCase()});
      if(b.n%2===0)e2.send({t:'bee',op:'ans',text:w});else e2.send({t:'bee',op:'ans',text:'zzz'});
    }
    if(e1.last('bee').st==='done')break;
  }
  await sleep(300);
  const fin=e1.last('bee');ok(fin.st==='done'&&fin.results.length===2,'bee finished with standings');
  ok(fin.results[0].name==='Bea'&&fin.results[0].place===1&&fin.results[0].prize===4000&&fin.results[1].prize===2000,'1st 4000, 2nd 2000: '+JSON.stringify(fin.results.map(r=>[r.name,r.pts,r.prize])));
  ok(e1.money===m0b[0]+4000&&e2.money===m0b[1]+2000,'bee prizes paid by the server');
  ok(e3.last('bee')==null||e3.last('bee').st!=='done','non-player did not get results');
  e1.send({t:'lb'});await sleep(100);ok(e1.last('lb').lb.bee[0].name==='Bea'&&e1.last('lb').lb.bee[0].wins===1,'bee board updated');
  // late answers and cancel
  e1.send({t:'bee',op:'join'});await sleep(3300);ok(e1.last('bee').st==='idle'||e1.last('notice').msg.includes('cancelled'),'one-player bee is cancelled');
  // reports
  d.send({t:'report',id:b.id,reason:'abuse'});await sleep(100);ok(d.last('notice').msg.includes('Report sent'),'report accepted');
  // admin
  const r=await fetch('http://localhost:'+PORT+'/admin/state?key=k').then(x=>x.json());ok(r.online.length>=4&&r.reports.length===1,'admin state');
  const r2=await fetch('http://localhost:'+PORT+'/admin/state?key=x');ok(r2.status===403,'admin needs key');
  console.log('fails',fails);srv.kill();process.exit(fails?1:0);
})().catch(e=>{console.log('ERR',e);srv.kill();process.exit(1)});
